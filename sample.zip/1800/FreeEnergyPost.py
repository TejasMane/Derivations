
# coding: utf-8

# In[1]:

import numpy as np
import pylab as pl
pl.rcParams['figure.figsize']  = 12, 7.5
pl.rcParams['lines.linewidth'] = 1.5
pl.rcParams['font.family']     = 'serif'
# pl.rcParams['font.weight']     = 'bold'
pl.rcParams['font.size']       = 20
pl.rcParams['font.sans-serif'] = 'serif'
pl.rcParams['axes.linewidth']  = 1.5
pl.rcParams['axes.titlesize']  = 'medium'
pl.rcParams['axes.labelsize']  = 'medium'

pl.rcParams['xtick.major.size'] = 8
pl.rcParams['xtick.minor.size'] = 4
pl.rcParams['xtick.major.pad']  = 8
pl.rcParams['xtick.minor.pad']  = 8
pl.rcParams['xtick.color']      = 'k'
pl.rcParams['xtick.labelsize']  = 'medium'
pl.rcParams['xtick.direction']  = 'in'

pl.rcParams['ytick.major.size'] = 8
pl.rcParams['ytick.minor.size'] = 4
pl.rcParams['ytick.major.pad']  = 8
pl.rcParams['ytick.minor.pad']  = 8
pl.rcParams['ytick.color']      = 'k'
pl.rcParams['ytick.labelsize']  = 'medium'
pl.rcParams['ytick.direction']  = 'in'


# In[2]:

import pandas


# In[3]:

T = np.double(np.loadtxt('t_final.txt'))


# In[4]:

T


# In[5]:

k_al = np.loadtxt('bulk_' + str(int(T)) + '/free_energy_data/k_al.txt')    # [eV/A^2]
k_o = np.loadtxt('bulk_' + str(int(T)) + '/free_energy_data/k_o.txt')    # [eV/A^2]
lx = np.loadtxt('surf_' + str(int(T)) + '/lx.txt', comments='#')
ly = np.loadtxt('surf_' + str(int(T)) + '/ly.txt', comments='#')
lz = np.loadtxt('bulk_' + str(int(T)) + '/lz.txt', comments='#')


# ## SOLID 

# In[6]:

df = pandas.read_table('bulk_' + str(int(T)) + '/free_energy_data/bulk_switch_data.txt', comment='#', delim_whitespace=True)

PE_minus_W = np.array(df['pe']) - np.array(df['f_spring_aluminum']) - np.array(df['f_spring_oxygen'])
Lambda = np.array(df['f_spring_aluminum[1]']) 

split_PE_minus_W = np.split(PE_minus_W, 6)
split_Lambda = np.split(Lambda, 6)

PE_minus_W_forward = np.concatenate((split_PE_minus_W[1],split_PE_minus_W[2] ), axis = 0)
Lambda_forward = np.concatenate((split_Lambda[1],split_Lambda[2] ), axis = 0)

PE_minus_W_backward = np.concatenate((split_PE_minus_W[4],split_PE_minus_W[5] ), axis = 0)
Lambda_backward = np.concatenate((split_Lambda[4],split_Lambda[5] ), axis = 0)

pl.plot(Lambda_forward,PE_minus_W_forward , label = 'solid forward')
pl.plot(Lambda_backward ,PE_minus_W_backward, label = 'solid backward')
pl.legend()
pl.show()
pl.clf()
# In[7]:

i_forward = np.trapz(y = PE_minus_W_forward, x = Lambda_forward)
i_backward = np.trapz(y = PE_minus_W_backward, x = Lambda_backward)

W = (i_forward - i_backward) / 2

import scipy.constants as sc

kB = sc.value('Boltzmann constant in eV/K')
eV = sc.value('electron volt')
hbar = sc.value('Planck constant over 2 pi in eV s')
mu = sc.value('atomic mass constant')


V =  lx * ly * lz      # [A^3]

m_al = 26.981539     # [g/mol]
m_o = 15.9994     # [g/mol]
natoms = 2160 # Number of atoms.
natoms_al = 864
natoms_o = 1296

omega_al  = np.sqrt(k_al*eV/(m_al*mu)) * 1.0e+10 # [1/s]
omega_o   = np.sqrt(k_o*eV/(m_o*mu)) * 1.0e+10 # [1/s]

F_harm_al = 3 * natoms_al * kB * T * np.log(hbar * omega_al/(kB * T))
F_harm_o  = 3 * natoms_o  * kB * T * np.log(hbar * omega_o/(kB * T))

F_CM_al = (kB*T)*np.log((natoms_al/V) * (2*np.pi*kB*T / (natoms*k_al))**(3./2.))
F_CM_o  = (kB*T)*np.log((natoms_o/V) * (2*np.pi*kB*T / (natoms*k_o))**(3./2.))

F_solid     = (F_harm_al + F_harm_o + W + F_CM_al + F_CM_o) / natoms

np.savetxt('free_energy_solid_' + str(int(T)) + '.txt', np.array([F_solid]), delimiter='\n')


# ## LIQUID

# In[8]:

###############LIQUID####################################
df = pandas.read_table('surf_' + str(int(T)) + '/free_energy_data/switch_print_data.txt', comment='#', delim_whitespace=True)

PE_minus_W = np.array(df['pe']) - np.array(df['f_spring_aluminum']) - np.array(df['f_spring_oxygen'])
Lambda = np.array(df['f_spring_aluminum[1]']) 

split_PE_minus_W = np.split(PE_minus_W, 6)
split_Lambda = np.split(Lambda, 6)

PE_minus_W_forward = np.concatenate((split_PE_minus_W[1],split_PE_minus_W[2] ), axis = 0)
Lambda_forward = np.concatenate((split_Lambda[1],split_Lambda[2] ), axis = 0)

PE_minus_W_backward = np.concatenate((split_PE_minus_W[4],split_PE_minus_W[5] ), axis = 0)
Lambda_backward = np.concatenate((split_Lambda[4],split_Lambda[5] ), axis = 0)

pl.plot(Lambda_forward,PE_minus_W_forward , label = 'solid forward')
pl.plot(Lambda_backward ,PE_minus_W_backward, label = 'solid backward')
pl.legend()
pl.show()
pl.clf()
# In[9]:

i_forward = np.trapz(y = PE_minus_W_forward, x = Lambda_forward)
i_backward = np.trapz(y = PE_minus_W_backward, x = Lambda_backward)

W = (i_forward - i_backward) / 2

import scipy.constants as sc

kB = sc.value('Boltzmann constant in eV/K')
eV = sc.value('electron volt')
hbar = sc.value('Planck constant over 2 pi in eV s')
mu = sc.value('atomic mass constant')


V =  lx * ly * lz      # [A^3]
m_al = 26.981539     # [g/mol]
m_o = 15.9994     # [g/mol]
natoms = 2160 # Number of atoms.
natoms_al = 864
natoms_o = 1296

omega_al  = np.sqrt(k_al*eV/(m_al*mu)) * 1.0e+10 # [1/s]
omega_o   = np.sqrt(k_o*eV/(m_o*mu)) * 1.0e+10 # [1/s]

F_harm_al = 3 * natoms_al * kB * T * np.log(hbar * omega_al/(kB * T))
F_harm_o  = 3 * natoms_o  * kB * T * np.log(hbar * omega_o/(kB * T))

F_CM_al = (kB*T)*np.log((natoms_al/V) * (2*np.pi*kB*T / (natoms*k_al))**(3./2.))
F_CM_o  = (kB*T)*np.log((natoms_o/V) * (2*np.pi*kB*T / (natoms*k_o))**(3./2.))

F_surface     = (F_harm_al + F_harm_o + W + F_CM_al + F_CM_o) / natoms

np.savetxt('free_energy_surface_' + str(int(T)) + '.txt', np.array([F_surface]), delimiter='\n')


# In[10]:

# Computing surface free energy
surface_free_energy = (F_surface - F_solid) * natoms / (2 * lx * ly)


# In[11]:

surface_free_energy 


# In[12]:

# converting to J/m^2
surface_free_energy*= 16.02


# In[13]:

F_surface


# In[14]:

F_solid


# In[15]:

np.savetxt('surface_free_energy_J_m^2_' + str(int(T)) + '.txt', np.array([surface_free_energy]), delimiter='\n')


# In[ ]:



