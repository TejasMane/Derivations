cd bulk_1800 

lmp_serial -in bulk_1800_msd.txt -sf omp 

echo "lammps-daily -in bulk_1800_msd.txt -sf omp  DONE" > progress\bulk_1800_msd.txt

python spring.py


lmp_serial -in bulk_1800_switch.txt -sf omp 

echo "lammps-daily -in bulk_1800_switch.txt -sf omp DONE" > progress\bulk_1800_switch.txt

cd ..\

copy bulk_1800\surf_restart surf_1800\ 
copy bulk_1800\free_energy_data\k_al.txt surf_1800\free_energy_data\ 
copy bulk_1800\free_energy_data\k_o.txt  surf_1800\free_energy_data\ 
copy bulk_1800\t_final.txt surf_1800\ 
copy bulk_1800\t_final.txt t_final.txt

cd surf_1800
lmp_serial -in surf_1800_switch.txt -sf omp 

echo "lammps-daily -in surf_1800_switch.txt -sf omp DONE" > progress\surf_1800_switch.txt

python FreeEnergyPost.py


