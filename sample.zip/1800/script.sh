#!/bin/bash

cd bulk_2100 

lammps-daily -in bulk_2100_msd.txt -sf omp 

echo "lammps-daily -in bulk_2100_msd.txt -sf omp  DONE" > ../progress/bulk_2100_msd.txt > log.txt

python spring.py



lammps-daily -in bulk_2100_switch.txt -sf omp 

echo "lammps-daily -in bulk_2100_switch.txt -sf omp DONE" > ../progress/bulk_2100_switch.txt > log.txt

cd ../

cp bulk_2100/surf_restart surf_2100/
cp bulk_2100/free_energy_data/k_al.txt surf_2100/free_energy_data/
cp bulk_2100/free_energy_data/k_o.txt surf_2100/free_energy_data/
cp bulk_2100/t_final.txt surf_2100/
cp bulk_2100/t_final.txt t_final.txt

cd surf_2100
lammps-daily -in surf_2100_switch.txt -sf omp 

echo "lammps-daily -in surf_2100_switch.txt -sf omp DONE" > ../progress/surf_2100_switch.txt > log.txt

cd ../
python FreeEnergyPost.py



