
# coding: utf-8

# In[1]:

import numpy as np
import pandas as pd


# In[2]:

Temp = np.loadtxt('t_final.txt' )


kB = 1.38 * 1e-4


# In[3]:

KT = Temp * kB / 1.602


# In[4]:


# In[5]:

df = pd.read_table('free_energy_data/bulk_print_data.txt', comment='#', delim_whitespace= True)


# In[6]:

msd_al = np.array(df['msd_al'])



# In[7]:

msd_o = np.array(df['msd_o'])


# In[8]:

msd_al_average = np.mean(msd_al[-1100:-1000])


# In[9]:

msd_o_average = np.mean(msd_o[-1100:-1000])






# In[12]:

k_Al = 3 * KT / msd_al_average
k_o = 3 * KT / msd_o_average


print('k_Al, k_o are  ', k_Al, k_o)

# In[13]:

np.savetxt('free_energy_data/k_al.txt', np.array([k_Al]), delimiter='\n')
np.savetxt('free_energy_data/k_o.txt', np.array([k_o]), delimiter='\n')


# In[ ]:



